<!-- README.md -->

# Use 
`node scraper.js`



# Credit
Adapted from [this GitHub repository](https://github.com/mskian/cricket-api-nodejs)